<?php
include __DIR__ . '/header.php';
?>
<h1>About This Project</h1>
<p>This project is a demo Travel Destinations CMS built for coursework. The admin allows you to manage destinations and upload photos. The frontend reads data from the CMS and displays destinations, galleries and YouTube videos (if present).</p>
<?php include __DIR__ . '/footer.php'; ?>
