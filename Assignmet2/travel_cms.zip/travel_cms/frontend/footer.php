</div>
<footer class="bg-light py-4 mt-5">
  <div class="container text-center">
    <small>&copy; 2025 Travel CMS</small>
  </div>
</footer>
<script src="/frontend/js/bootstrap.bundle.min.js"></script>
</body>
</html>
